import 'package:flutter/material.dart';
import 'package:tp_mobilite/classDescription.dart';

class PageFilm extends StatelessWidget {
  const PageFilm({Key? key, required this.imdbID}) : super(key: key);
  final String imdbID;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        centerTitle: true,
        title: Text('Filmographie'),
      ),
      body: Center(
        child: FutureBuilder<Description>(
            future: DescriptionFonction.getDescription(imdbID),
            builder: (BuildContext context, AsyncSnapshot snapshot) {
              print(snapshot);
              if (!snapshot.hasData) {
                return CircularProgressIndicator();
              } else {
                return Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          snapshot.data.titre,
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 20.00),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          snapshot.data.genre,
                          style: TextStyle(fontSize: 15.00),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          snapshot.data.dateSortie,
                          style: TextStyle(fontSize: 15.00),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.network(snapshot.data.afficheImg),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          snapshot.data.duree,
                          style: TextStyle(fontSize: 15.00),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          snapshot.data.acteurs,
                          style: TextStyle(fontSize: 15.00),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          snapshot.data.synopsis,
                          style: TextStyle(fontSize: 15.00),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          snapshot.data.recompense,
                          style: TextStyle(fontSize: 15.00),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          snapshot.data.realisateur,
                          style: TextStyle(fontSize: 15.00),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          snapshot.data.auteur,
                          style: TextStyle(fontSize: 15.00),
                        ),
                      ),
                    ],
                  ),
                );
              }
            }),
      ),
    );
  }
}
