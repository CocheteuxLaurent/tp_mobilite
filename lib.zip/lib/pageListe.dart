import 'package:flutter/material.dart';
import 'package:tp_mobilite/PageFilm.dart';
import 'package:tp_mobilite/classFilm.dart';

class PageListe extends StatelessWidget {
  const PageListe({Key? key, required this.valeurRecup}) : super(key: key);
  final String valeurRecup;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        centerTitle: true,
        title: Text('Filmographie'),
      ),
      body: Center(
        child: FutureBuilder<List<Film>>(
          future: FilmFonction.getFilm(valeurRecup),
          builder: (BuildContext context, AsyncSnapshot snapshot) {
            if (!snapshot.hasData) {
              return CircularProgressIndicator();
            } else {
              return ListView.builder(
                itemCount: snapshot.data.length,
                itemBuilder: (BuildContext context, int index) {
                  final id = snapshot.data[index].idFilm;
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => PageFilm(
                                  imdbID: id,
                                )),
                      );
                    },
                    child: Card(
                      color: Colors.blue,
                      elevation: 3,
                      margin: EdgeInsets.all(20),
                      child: ListTile(
                        minVerticalPadding: 10,
                        title: Text(
                          snapshot.data[index].titre,
                          style: TextStyle(
                              color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  );
                },
              );
            }
          },
        ),
      ),
    );
  }
}
